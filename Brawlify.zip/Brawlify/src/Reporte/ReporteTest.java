package Reporte;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ReporteTest {

    @Before
    public void iniciarReporte(){

    }

    @Test
    public void getComentario() {
    }

    @Test
    public void setComentario() {
    }

    @Test
    public void getUsuario() {
    }

    @Test
    public void setUsuario() {
    }

    @Test
    public void getCancionReportada() {
    }

    @Test
    public void setCancionReportada() {
    }
}