package Exceptions;

public class ContrasenaIncorrecta extends Exception {
    public String toString() {
        return "Contraseña Incorrecta";
    }
}
