package Exceptions;

public class UsuarioNoExistente extends Exception {
    public String toString() {
        return "Usuario no existente en la aplicacion";
    }
}
